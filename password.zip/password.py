from tkinter import *
from PIL import Image ,ImageTk
from tkinter import ttk
import string
import random
import pyperclip

root = Tk()
root.geometry('600x500')
root.title("Random password generator")
root.configure(bg='lightblue')
photo = PhotoImage(file = "pass2.png")
root.iconphoto(False, photo)

userinput = IntVar()
pswd=StringVar()

def generatpass():
    gentps = userinput.get()

    charvalues = string.ascii_letters +string.ascii_letters +string.punctuation
    result1 = "".join([random.choice(charvalues) for i in range(gentps)])
    pswd.set(result1)

def clear_text():
    showpaswd.delete(0, END)
    e1.delete(0, END)

def copyPass():
    pyperclip.copy(pswd.get())

l1 = Label(text="Random Password Generator" ,bg = "lightblue" , font ="arial 20 bold",fg = "white")
l1.pack(pady =30)
 
l2 = Label(text="Enter Password lenght"  ,bg = "lightblue", font ="arial 20 bold",fg = "white",padx=20)
l2.pack( )


e1 = Entry(root, width=30 ,textvariable=userinput)
e1.pack(ipady=5,pady=30)

Button(text="Generate Password",cursor="hand2" , command=generatpass ,font ="arial 10 bold").pack()

showpaswd = Entry(root , textvariable= pswd, width = 24, font='arial 16', )
showpaswd.pack(pady =30 )

b1 = Button(text="  copy  ",cursor="hand2", command =copyPass ,font ="arial 10 bold")
b1.pack(padx= 100,pady=10)

b2 = Button(text="  Reset  ",cursor="hand2", command =clear_text,font ="arial 10 bold" )
b2.pack()

b3 = Button(text="  Close  ",cursor="hand2",command=quit,font ="arial 10 bold")
b3.pack(padx=200,pady=10)

root.mainloop()