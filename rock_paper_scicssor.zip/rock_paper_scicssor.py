from tkinter import *
from PIL import Image ,ImageTk
from tkinter import ttk
import string
import random
import pyperclip

root = Tk()
root.geometry('800x600')
root.title("Rock Paper Scissor")
# root.configure(bg='lightblue')
photo = PhotoImage(file = "rps.png")
root.iconphoto(False, photo)


result_win = StringVar()
Player = ""
computer_choise = ""
global photo_rock
global photo_rock
global pic_label_player
global pic_label_computer
     


frame = Frame(root, bg="lightblue",width=800, height=600)
# bg="yellow"
frame.pack_propagate(False)
frame.pack(fill="both",expand=True)

l1 = Label(frame,text="Rock Paper Scissor",font="arial 20 bold" ,bg = "white")
# ,bg = "grey"
l1.pack(pady=20)

f1 = Frame(frame,bg = "lightblue" )
# bg = "green"
f1.pack(fill="both")
 

l1 = Label(f1,text="Player",font="arial 15 bold",bg = "white" )
# ,bg = "green"
l1.pack(side=LEFT ,padx=60,pady=10,expand = True,)

l2 = Label(f1,text="VS",font="arial 15 bold",bg = "white" )
# ,bg = "green"
l2.pack(side=LEFT ,padx=60,pady=10,expand = True,)

l3 = Label(f1, text="Computer", font="arial 15 bold",bg = "white" )
# ,bg = "green"
l3.pack(side=LEFT ,padx=60,pady=10,expand = True,)

f2 = Frame(frame,width=200,height=150,bg = "lightblue")
# ,bg = "red"
f2.pack_propagate(False)
f2.pack(fill="both",pady = 20)


f2_1 = Frame(f2, width=400,height= 75,bg = "lightblue")
# ,bg = "blue"
f2_1.pack_propagate(False)
f2_1.pack(side=LEFT,expand= True,fill="both" )
f2_2 = Frame(f2, width=400,height= 75,bg = "lightblue")
# ,bg = "orange"
f2_2.pack_propagate(False)
f2_2.pack(side=RIGHT,expand= True,fill="both" )


photo_rock = Image.open("rock.png").resize((200,150))
photo_rock = ImageTk.PhotoImage(photo_rock)

photo_paper = Image.open("paper.png").resize((200,150))
photo_paper = ImageTk.PhotoImage(photo_paper)

photo_scissor = Image.open("scissor.png").resize((200,150))
photo_scissor = ImageTk.PhotoImage(photo_scissor)

photo_rock2 = Image.open("rock2.png").resize((200,150))
photo_rock2 = ImageTk.PhotoImage(photo_rock2)

photo_paper2 = Image.open("paper2.png").resize((200,150))
photo_paper2 = ImageTk.PhotoImage(photo_paper2)

photo_scissor2 = Image.open("scissor2.png").resize((200,150))
photo_scissor2 = ImageTk.PhotoImage(photo_scissor2)

pic_label_player = Label(f2_1, )
pic_label_player.pack()



pic_label_computer = Label(f2_2)
pic_label_computer.pack()

def update_image_in_label_rock():
    global pic_label_player
    pic_label_player.config(image=photo_rock)

def is_rock():
    Player = "Rock"
    pic_label_player = Label(f2_1, image=photo_rock)
    pic_label_player.pack()
    computer_choise = random.choice(["Rock", "Paper","Scissor"])
    if (Player == "Rock" and computer_choise == "Rock"):
        pic_label_computer.config(image=photo_rock2)
        op = "Match Draw"
        result_win.set(op)

    elif(Player == "Rock" and computer_choise == "Paper"):
        pic_label_computer.config(image=photo_paper2)
        op = "Computer Win"
        result_win.set(op)

    elif(Player == "Rock" and computer_choise == "Scissor"):
        pic_label_computer.config(image=photo_scissor2)
        op= "Player Win"
        result_win.set(op)

def update_image_in_label_paper():
    global pic_label_player
    pic_label_player.config(image=photo_paper)

def is_paper():
    Player = "Paper"
    computer_choise = random.choice(["Rock", "Paper","Scissor"])

    if(Player == "Paper" and computer_choise == "Rock"):
        pic_label_computer.config(image=photo_rock2)
        op= "Player Win"
        result_win.set(op)

    elif(Player == "Paper" and computer_choise == "Paper"):
        pic_label_computer.config(image=photo_paper2)
        op = "Match Draw"
        result_win.set(op)

    elif(Player == "Paper" and computer_choise == "Scissor"):
        pic_label_computer.config(image=photo_scissor2)
        op = "Computer Win"
        result_win.set(op)





def update_image_in_label_scissor():
    global pic_label_player
    pic_label_player.config(image=photo_scissor)

def is_scissor():
    Player = "Scissor"

    pic_label_player = Label(f2_1, image=photo_scissor)
    pic_label_player.pack()
    computer_choise = random.choice(["Rock", "Paper","Scissor"])

    if(Player == "Scissor" and computer_choise == "Scissor"):
        pic_label_computer.config(image=photo_scissor2)
        op = "Match Draw"
        result_win.set(op)

    elif(Player == "Scissor" and computer_choise == "Rock"):
        pic_label_computer.config(image=photo_rock2)
        op = "Computer Win"
        result_win.set(op)
    elif(Player == "Scissor" and computer_choise == "Paper"):
        pic_label_computer.config(image=photo_paper2)
        op= "Player Win"
        result_win.set(op)
    
    

 
f3 = Frame(frame,width=200,height=100, bg="lightblue")
# ,bg = "red"
f3.pack_propagate(False)
f3.pack(fill="both",pady = 10)


b1 = Button(f3, text="Rock",cursor="hand2", font = "arial 15 bold",width=10,height=80,command = lambda :[update_image_in_label_rock(),is_rock()])
b1.pack(side=LEFT ,padx=60,pady=10,expand = True,)

b2 = Button(f3, text="Paper",cursor="hand2", font = "arial 15 bold",width=10,height=80,command = lambda:[update_image_in_label_paper(), is_paper() ])
b2.pack(side=LEFT,padx=60,pady=10,expand = True,)

b3 = Button(f3, text="Scissor",cursor="hand2", font = "arial 15 bold",width=10,height=80,command = lambda :[ update_image_in_label_scissor(),is_scissor() ])
b3.pack(side=LEFT,padx=60,pady=10,expand = True)
 
e1 = Entry(frame,text = "output",textvariable=result_win,fg="black", font = "arial 20 bold",width=20)
e1.pack(pady=5,expand = True,)

def play_again():
    e1.delete(0,END)

play_again_button = Button(frame,text = "Play Again",fg="black", font = "arial 15 bold" ,command=play_again)
play_again_button.pack(expand = True,)

close_button = Button(frame,text = "Quit",fg="black", font = "arial 15 bold",command=quit)
close_button.pack(expand = True,)





root.mainloop()