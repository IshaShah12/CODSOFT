from tkinter import *
from tkinter import ttk
import string
 
 

root = Tk()
root.geometry('540x505')
root.title("Calculator")
root.configure(bg='black')
photo = PhotoImage(file = "calculator.png")
root.iconphoto(False, photo)

def btn_click(item):
    global expression
    expression = expression + str(item)
    input_text.set(expression)

def bt_clear(): 
    global expression 
    expression = "" 
    input_text.set("")
 
def bt_equal():
    global expression
    result = str(eval(expression)) # 'eval':This function is used to evaluates the string expression directly
    input_text.set(result)
    expression = ""
 
expression = ""

# 'StringVar()' :It is used to get the instance of input field
input_text = StringVar()

entry = Entry(root, textvariable= input_text,width=20, font=("Arial", 20))
entry.pack( expand = True, fill = "both")
 
# l1 = Label(textvariable=input_text, font="arial 20 bold",width=700 , height=3,anchor="se")
# l1.pack( expand = True, fill = "both")
 
f1 = Frame(root, bg ="grey",borderwidth=3,width=540 ,height=80,relief = SUNKEN)
f1.pack_propagate(False)
f1.pack(anchor = "nw",expand = True, fill = "both")

button_ce = Button(f1, fg = "white",bg = "#40444b",text = "CE" ,cursor="hand2", font = "arial 15 bold",width=10,height=80, command = lambda: bt_clear())
button_ce.pack(side = LEFT, expand = True, fill = "both")

button_c = Button(f1, fg = "white",text = "C" ,bg = "#40444b",cursor="hand2",font = "arial 15 bold",width=10,height=80, command = lambda: bt_clear())
button_c.pack(side = LEFT, expand = True, fill = "both")

button_div = Button(f1, fg = "white",text = "÷" ,bg = "#40444b",cursor="hand2",font = "arial 16 bold",width=10,height=80, command = lambda: btn_click("/") )
button_div.pack(side = LEFT, expand = True, fill = "both")


f2 = Frame(root, bg ="grey",borderwidth=3,width=540  ,height=80, relief = SUNKEN)
f2.pack_propagate(False)
f2.pack(anchor = "nw",expand = True, fill = "both")

button_7 = Button(f2, fg = "white",text = "7" ,bg = "#40444b",cursor="hand2", font = "arial 15 bold",width=10,height=80, command = lambda: btn_click(7))
button_7.pack(side = LEFT, expand = True, fill = "both")

button_8 = Button(f2, fg = "white",text = "8" ,bg = "#40444b",cursor="hand2",font = "arial 15 bold",width=10,height=80, command = lambda: btn_click(8) )
button_8.pack(side = LEFT, expand = True, fill = "both")
 
button_9 = Button(f2, fg = "white",bg = "#40444b",text = "9" ,cursor="hand2",font = "arial 15 bold",width=10,height=80, command = lambda: btn_click(9))
button_9.pack(side = LEFT, expand = True, fill = "both")
 
button_x = Button(f2, fg = "white",bg = "#40444b",text = "x" ,cursor="hand2",font = "arial 16 bold",width=10,height=80, command = lambda: btn_click("*"))
button_x.pack(side = LEFT, expand = True, fill = "both")


f3 = Frame(root, bg ="grey",borderwidth=3,width=540 ,height=80, relief = SUNKEN)
f3.pack_propagate(False)
f3.pack(anchor = "nw",expand = True, fill = "both")

button_4 = Button(f3,bg = "#40444b",fg = "white",text = "4" ,cursor="hand2", font = "arial 15 bold",width=10,height=80, command = lambda: btn_click(4))
button_4.pack(side = LEFT, expand = True, fill = "both") 

button_5 = Button(f3, fg = "white",bg = "#40444b",text = "5" ,cursor="hand2",font = "arial 15 bold",width=10,height=80, command = lambda: btn_click(5))
button_5.pack(side = LEFT, expand = True, fill = "both")
 
button_6 = Button(f3, fg = "white",bg = "#40444b",text = "6" ,cursor="hand2",font = "arial 15 bold",width=10,height=80, command = lambda: btn_click(6))
button_6.pack(side = LEFT, expand = True, fill = "both")
 
button_sub = Button(f3, fg = "white",bg = "#40444b",text = "-" ,cursor="hand2",font = "arial 16 bold",width=10,height=80, command = lambda: btn_click("-"))
button_sub.pack(side = LEFT, expand = True, fill = "both")


f4 = Frame(root, bg ="grey",borderwidth=3,width=540 ,height=80, relief = SUNKEN)
f4.pack_propagate(False)
f4.pack( anchor = "nw",expand = True,fill = "both")

button_1 = Button(f4,bg = "#40444b",fg = "white",text = "1" ,cursor="hand2", font = "arial 15 bold",width=10,height=80, command = lambda: btn_click(1))
button_1.pack(side = LEFT, expand = True, fill = "both")

button_2 = Button(f4, fg = "white",bg = "#40444b",text = "2" ,cursor="hand2",font = "arial 15 bold",width=10,height=80, command = lambda: btn_click(2))
button_2.pack(side = LEFT, expand = True, fill = "both")
 
button_3 = Button(f4, fg = "white",bg = "#40444b",text = "3" ,cursor="hand2",font = "arial 15 bold",width=10,height=80, command = lambda: btn_click(3))
button_3.pack(side = LEFT, expand = True, fill = "both")
 
button_add = Button(f4,fg = "white",bg = "#40444b",text = "+" ,cursor="hand2",font = "arial 16 bold",width=10,height=80, command = lambda: btn_click("+"))
button_add.pack(side = LEFT, expand = True, fill = "both")


f5 = Frame(root, bg ="grey",borderwidth=3,width=540 ,height=80, relief = SUNKEN)
f5.pack_propagate(False)
f5.pack(anchor = "nw",expand = True, fill = "both")

button_0 = Button(f5,bg = "#40444b",fg = "white",text = "0" ,cursor="hand2", font = "arial 15 bold",width=10,height=80, command = lambda: btn_click(0))
button_0.pack(side = LEFT, expand = True, fill = "both")

button_dot = Button(f5, fg = "white",bg = "#40444b",text = "." ,cursor="hand2",font = "arial 15 bold",width=10,height=80, command = lambda: btn_click("."))
button_dot.pack(side = LEFT, expand = True, fill = "both")
 
button_mod = Button(f5, fg = "white",bg = "#40444b",text = "%" ,cursor="hand2",font = "arial 15 bold",width=10,height=80, command = lambda: btn_click("%"))
button_mod.pack(side = LEFT, expand = True, fill = "both")
 
button_equal = Button(f5, fg = "white",bg = "#40444b",text = "=" ,cursor="hand2",font = "arial 16 bold",width=10,height=80, command = lambda: bt_equal())
button_equal.pack(side = LEFT, expand = True, fill = "both")

root.mainloop()